<?php
/**
 *  Silence Is Golden
 */