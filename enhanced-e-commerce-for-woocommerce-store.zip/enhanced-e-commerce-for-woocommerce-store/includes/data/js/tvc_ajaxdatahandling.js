"use strict";
var myAjaxNonces;